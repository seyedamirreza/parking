package ir.ac.kntu;

import java.util.ArrayList;

public class IMDb {
    private ArrayList<Movie> movies;

    //TODO complete the class

    public void addMovie(Movie movie) {
        movies.add(movie);
    }

    public Movie[] getTop10Rated() {
        ;
        return null;
    }

    public String getMostRecentReview(Movie movie) {
      String last[]=new String[movie.getReviews().length];
      return last[movie.getReviews().length];
    }

}