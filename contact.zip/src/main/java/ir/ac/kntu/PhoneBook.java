package ir.ac.kntu;

import java.util.ArrayList;

public class PhoneBook {

    private final ArrayList<Contact> contacts;

    // don't change this method
    public PhoneBook(ArrayList<Contact> contacts) {
        this.contacts = contacts;
    }

    public PhoneBook() {
        contacts = new ArrayList<>();

    }

    // don't change method's signature.
    public void addContact(Contact contact) {
        boolean bool = true;
        for (int i = 0; i < contacts.size(); i++) {
            if (this.contacts.get(i).getId()==contact.getId()) {
                bool = false;
            }
        }
        if (bool) {
            contacts.add(contact);
        }
    }

    // don't change method's signature.
    public void deleteContact(Contact contact) {
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).equals(contact)) {
                contacts.remove(i);
            }
        }
    }

    // don't change method's signature.
    public void replaceContact(int oldContactId, Contact newContact) {
        for (int i = 0; i < contacts.size(); i++) {
            if (this.contacts.get(i).getId()==oldContactId) {
                contacts.get(i).setAddress(newContact.getAddress());
                contacts.get(i).setId(oldContactId);
                contacts.get(i).setPhone(newContact.getPhone());
                contacts.get(i).setName(newContact.getName());
            }
        }
    }

    // don't change method's signature.
    public Contact searchContactByPhone(String phone) {
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).getPhone() == phone) {
                return contacts.get(i);
            }

        }
        return null;
    }

    // don't change method's signature.
    public ArrayList<Contact> getContactsStartNameWith(String nameStarter) {
        ArrayList<Contact> ans = new ArrayList<>();
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).getName().charAt(0) == nameStarter.charAt(0)) {
                for (int j = 0; j < nameStarter.length(); j++) {
                    if (contacts.get(i).getName().charAt(j) == nameStarter.charAt(j)) {
                        ;
                    } else {
                        break;
                    }
                }
                ans.add(contacts.get(i));
            }
        }

        return ans;
    }

    // don 't change method's signature.
    public ArrayList<Contact> getContacts() {
        return contacts;

    }
}