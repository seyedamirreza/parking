package ir.ac.kntu;
public class Movie {
private String name;
private String director;
private String genre;
private double rating;
private int numberOfRates;
private String[] reviews;
    public Movie(String name, String director, String genre) {
    this.setName(name);
    this.setDirector(director);
    this.setGenre(genre);
    }
    public Movie() {

    }

    public void addReview(String review) {
        reviews[reviews.length]=review;
    }
    public String[] getReviews(){
        return reviews;
    }

    public void rate(double score) {
        this.setRating(score);
        setNumberOfRates(getNumberOfRates() + 1);
    }

    @Override
    public String toString() {
        return "Movie{" +
                "name='" + getName() + '\'' +
                ", director='" + getDirector() + '\'' +
                ", genre='" + getGenre() + '\'' +
                ", rating=" + getRating() +
                ", reviews=" + reviews +
                ", numberOfRates=" + getNumberOfRates() +
                '}';

    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getNumberOfRates() {
        return numberOfRates;
    }

    public void setNumberOfRates(int numberOfRates) {
        this.numberOfRates = numberOfRates;
    }
}